# Traffic Cones > augmentated version
https://universe.roboflow.com/robotica-xftin/traffic-cones-4laxg

Provided by a Roboflow user
License: Public Domain

Dataset made by a brazilian IT student, on high school.
I'am a complete newbie, sorry about any image that is mislabeled. 
ﾠﾠ
Project made to train a neural network to detect traffic cones, for a robotics competition called Robo Trekking, the brazillian version of Robo Magellan.
ﾠﾠ
##### The images were downloaded using a python library called  [**DuckDuckGoImages.**](https://pypi.org/project/DuckDuckGoImages/)

##### The images were labeled using Microsoft [**vott**](https://github.com/microsoft/VoTT)