# traffic-cone-OpenCV-detection
An experiment using contours and bounding box features from OpenCV to detect traffic cones in real time.
